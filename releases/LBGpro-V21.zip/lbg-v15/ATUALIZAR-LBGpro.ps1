$ErrorActionPreference="Stop"
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$planFile=Join-Path $root "updates\pending-update.json"
if(!(Test-Path $planFile)){Write-Host "Nenhuma atualizacao preparada."; Read-Host "Enter para sair"; exit 1}
$plan=Get-Content $planFile -Raw | ConvertFrom-Json
$zip=Join-Path $root ("updates\"+$plan.package)
if(!(Test-Path $zip)){Write-Host "Pacote nao encontrado."; Read-Host "Enter para sair"; exit 1}
$temp=Join-Path $env:TEMP ("LBGpro-update-"+[guid]::NewGuid())
New-Item -ItemType Directory -Path $temp | Out-Null
try {
 Expand-Archive -LiteralPath $zip -DestinationPath $temp -Force
 $source=$temp
 $dirs=Get-ChildItem $temp -Directory
 if($dirs.Count -eq 1 -and (Test-Path (Join-Path $dirs[0].FullName "server.js"))){$source=$dirs[0].FullName}
 if(!(Test-Path (Join-Path $source "server.js")) -or !(Test-Path (Join-Path $source "public"))){throw "Pacote nao contem uma instalacao valida do LBGpro."}
 $preserve=@("pdv.sqlite","pdv.sqlite-wal","pdv.sqlite-shm","data.json","backups","updates")
 Get-ChildItem $source -Force | ForEach-Object {
   if($preserve -notcontains $_.Name){Copy-Item $_.FullName (Join-Path $root $_.Name) -Recurse -Force}
 }
 Remove-Item $planFile -Force
 Write-Host ""; Write-Host "LBGpro atualizado com sucesso."; Write-Host ("Backup de seguranca: "+$plan.safetyBackup)
} catch { Write-Host ""; Write-Host ("Falha na atualizacao: "+$_.Exception.Message); Write-Host "Seus dados foram preservados." }
finally {Remove-Item $temp -Recurse -Force -ErrorAction SilentlyContinue}
Read-Host "Enter para sair"
