# LBGpro SmartPOS V2

Aplicativo Android nativo (Kotlin), sem WebView, para terminais SmartPOS PagBank.

## Implementado nesta versão
- Login no servidor LBGpro.
- Lista de mesas livres e ocupadas.
- Abertura de mesa diretamente no SmartPOS.
- Cardápio por categorias.
- Inclusão de quantidade, tamanho, adicionais e observação de cozinha.
- Edição dos itens de uma mesa já aberta.
- Envio ao servidor, estoque e fila de impressão cozinha/bar usando as regras do LBGpro.
- Visualização de subtotal, serviço, desconto, total, pago e restante.
- Pagamento PlugPag em crédito, débito e PIX.
- Baixa no LBGpro somente após retorno aprovado do terminal.
- Endpoint SmartPOS permite baixa por garçom/caixa/admin somente com requestId e referência da transação.
- Proteção contra repetição do mesmo requestId.

## Necessário antes da produção
1. Validar o Wrapper/PlugPag no terminal DEBUG real fornecido/liberado pelo PagBank.
2. Confirmar com o PagBank a versão do wrapper homologada para o modelo do terminal.
3. Usar URL HTTPS homologada para o servidor LBGpro.
4. Gerar e assinar o APK release conforme o processo de homologação PagBank.
5. Testar impressão física no SmartPOS; a impressão personalizada direta no hardware continua pendente.

O projeto não usa WebView.
