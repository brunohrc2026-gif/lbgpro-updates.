package br.com.lbgpro.smartpos

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class Api(var baseUrl:String) {
    var token:String?=null
    private fun request(method:String,path:String,body:JSONObject?=null):JSONObject {
        val c=URL(baseUrl.trimEnd('/')+path).openConnection() as HttpURLConnection
        c.requestMethod=method; c.connectTimeout=8000; c.readTimeout=15000
        c.setRequestProperty("Content-Type","application/json")
        token?.let{c.setRequestProperty("Authorization","Bearer $it")}
        if(body!=null){c.doOutput=true;c.outputStream.use{it.write(body.toString().toByteArray())}}
        val code=c.responseCode; val stream=if(code in 200..299)c.inputStream else c.errorStream
        val txt=stream?.bufferedReader()?.use{it.readText()} ?: "{}"
        val obj=JSONObject(txt)
        if(code !in 200..299) throw RuntimeException(obj.optString("error","HTTP $code"))
        return obj
    }
    fun login(user:String,password:String):JSONObject { val r=request("POST","/api/login",JSONObject().put("username",user).put("password",password));token=r.getString("token");return r }
    fun state()=request("GET","/api/state")
    fun createTableOrder(tableId:Long,items:JSONArray)=request("POST","/api/orders",JSONObject().put("orderType","table").put("tableId",tableId).put("items",items))
    fun updateOrderItems(orderId:Long,items:JSONArray)=request("PUT","/api/orders/$orderId/items",JSONObject().put("items",items))
    fun smartPosPay(orderId:Long,method:String,amount:Double,reference:String,requestId:String)=request("POST","/api/smartpos/orders/$orderId/pay",JSONObject().put("method",method).put("amount",amount).put("reference",reference).put("requestId",requestId))
}
