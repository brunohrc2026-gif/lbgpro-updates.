package br.com.lbgpro.smartpos

import android.content.Context
import java.util.concurrent.atomic.AtomicBoolean

data class PaymentResult(val approved:Boolean,val transactionCode:String,val transactionId:String,val raw:String)

/** Integração nativa PlugPag. Usa reflexão para manter compatibilidade entre releases do Wrapper nos terminais homologados. */
class PagBankGateway(private val context:Context) {
    private val busy=AtomicBoolean(false)
    fun pay(kind:String,cents:Int,reference:String):PaymentResult {
        if(!busy.compareAndSet(false,true)) throw IllegalStateException("Já existe uma transação em andamento")
        try {
            val plugPagClass=Class.forName("br.com.uol.pagseguro.plugpagservice.wrapper.PlugPag")
            val idClass=Class.forName("br.com.uol.pagseguro.plugpagservice.wrapper.PlugPagAppIdentification")
            val dataClass=Class.forName("br.com.uol.pagseguro.plugpagservice.wrapper.PlugPagPaymentData")
            val ident=idClass.getConstructor(String::class.java,String::class.java).newInstance("LBGpro","1.0.0")
            val plug=plugPagClass.getConstructor(Context::class.java,idClass).newInstance(context,ident)
            fun constant(name:String)=plugPagClass.getField(name).getInt(null)
            val type=when(kind){"credito"->constant("TYPE_CREDITO");"debito"->constant("TYPE_DEBITO");"pix"->constant("TYPE_PIX");else->throw IllegalArgumentException("Forma não suportada")}
            val avista=constant("INSTALLMENT_TYPE_A_VISTA")
            val ref=reference.filter{it.isLetterOrDigit()}.take(10).ifBlank{"LBGPRO"}
            val data=dataClass.getConstructor(Int::class.javaPrimitiveType,Int::class.javaPrimitiveType,Int::class.javaPrimitiveType,Int::class.javaPrimitiveType,String::class.java,Boolean::class.javaObjectType).newInstance(type,cents,avista,1,ref,true)
            val result=plugPagClass.getMethod("doPayment",dataClass).invoke(plug,data)
            val rc=result.javaClass.methods.firstOrNull{it.name=="getResult"}?.invoke(result) as? Int ?: -1
            val ok=rc==constant("RET_OK")
            fun str(n:String)=result.javaClass.methods.firstOrNull{it.name==n}?.invoke(result)?.toString().orEmpty()
            return PaymentResult(ok,str("getTransactionCode"),str("getTransactionId"),result.toString())
        } finally { busy.set(false) }
    }
}
